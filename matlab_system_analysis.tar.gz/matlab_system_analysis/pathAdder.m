function pathAdder()
addpath('../matlab_log_plot/');
addpath('../matlab_tbxFcn/');
addpath('../matlab_system_analysis/');
end